/**
 * ECPay Gateway - 精簡版單檔實作
 * 金流 + 物流統一入口
 */
import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import CryptoJS from 'crypto-js';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

// ============================================
// 環境變數
// ============================================
const {
  SUPABASE_URL = '',
  SUPABASE_SERVICE_KEY = '',
  ENCRYPTION_KEY = '',
  ADMIN_API_KEY = '',
  PORT = '3000'
} = process.env;

const supabase: SupabaseClient = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

// ============================================
// 工具函數
// ============================================

// AES 加密
function encrypt(text: string): string {
  const iv = CryptoJS.lib.WordArray.random(16);
  const encrypted = CryptoJS.AES.encrypt(text, CryptoJS.enc.Hex.parse(ENCRYPTION_KEY), {
    iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7
  });
  return iv.toString() + ':' + encrypted.ciphertext.toString();
}

// AES 解密
function decrypt(encrypted: string): string {
  const [ivHex, ciphertext] = encrypted.split(':');
  const decrypted = CryptoJS.AES.decrypt(
    { ciphertext: CryptoJS.enc.Hex.parse(ciphertext) } as CryptoJS.lib.CipherParams,
    CryptoJS.enc.Hex.parse(ENCRYPTION_KEY),
    { iv: CryptoJS.enc.Hex.parse(ivHex), mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 }
  );
  return decrypted.toString(CryptoJS.enc.Utf8);
}

// 產生 API Key
function generateApiKey(): string {
  return 'gk_' + CryptoJS.lib.WordArray.random(24).toString();
}

// 產生交易編號
function generateTradeNo(prefix = 'TX'): string {
  const ts = Date.now().toString(36).toUpperCase();
  const rand = CryptoJS.lib.WordArray.random(4).toString().substring(0, 8).toUpperCase();
  return (prefix + ts + rand).substring(0, 20);
}

// ECPay CheckMacValue
function calculateCheckMac(params: Record<string, string>, hashKey: string, hashIV: string): string {
  const sorted = Object.keys(params).sort().map(k => `${k}=${params[k]}`).join('&');
  const raw = `HashKey=${hashKey}&${sorted}&HashIV=${hashIV}`;
  const encoded = encodeURIComponent(raw).toLowerCase()
    .replace(/%2d/g, '-').replace(/%5f/g, '_').replace(/%2e/g, '.')
    .replace(/%21/g, '!').replace(/%2a/g, '*').replace(/%28/g, '(')
    .replace(/%29/g, ')').replace(/%20/g, '+');
  return CryptoJS.SHA256(encoded).toString().toUpperCase();
}

// 驗證 CheckMacValue
function verifyCheckMac(params: Record<string, string>, hashKey: string, hashIV: string): boolean {
  const received = params.CheckMacValue;
  if (!received) return false;
  const copy = { ...params };
  delete copy.CheckMacValue;
  return received.toUpperCase() === calculateCheckMac(copy, hashKey, hashIV);
}

// ECPay URLs
const ECPAY = {
  payment: {
    staging: 'https://payment-stage.ecpay.com.tw/Cashier/AioCheckOut/V5',
    production: 'https://payment.ecpay.com.tw/Cashier/AioCheckOut/V5'
  },
  logistics: {
    create: {
      staging: 'https://logistics-stage.ecpay.com.tw/Express/Create',
      production: 'https://logistics.ecpay.com.tw/Express/Create'
    },
    map: {
      staging: 'https://logistics-stage.ecpay.com.tw/Express/map',
      production: 'https://logistics.ecpay.com.tw/Express/map'
    }
  }
};

// ============================================
// Middleware
// ============================================

// API Key 認證
async function authMerchant(req: Request, res: Response, next: NextFunction) {
  const apiKey = req.headers['x-api-key'] as string;
  if (!apiKey) return res.status(401).json({ error: 'Missing API key' });

  const { data: merchant } = await supabase
    .from('gateway_merchants')
    .select('*')
    .eq('api_key', apiKey)
    .eq('is_active', true)
    .single();

  if (!merchant) return res.status(401).json({ error: 'Invalid API key' });
  
  (req as any).merchant = merchant;
  next();
}

// Admin 認證
function authAdmin(req: Request, res: Response, next: NextFunction) {
  const apiKey = req.headers['x-api-key'] as string;
  if (apiKey !== ADMIN_API_KEY) return res.status(401).json({ error: 'Unauthorized' });
  next();
}

// ============================================
// Express App
// ============================================
const app = express();

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health check
app.get('/health', (_, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

// ============================================
// 商家管理 (Admin)
// ============================================

// 建立商家
app.post('/api/v1/merchants', authAdmin, async (req: Request, res: Response) => {
  try {
    const { code, name, ecpay_merchant_id, ecpay_hash_key, ecpay_hash_iv, success_url, failure_url, webhook_url, is_staging = true } = req.body;
    
    if (!code || !name || !ecpay_merchant_id || !ecpay_hash_key || !ecpay_hash_iv || !success_url || !failure_url) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const apiKey = generateApiKey();
    
    const { data, error } = await supabase.from('gateway_merchants').insert({
      code, name, api_key: apiKey,
      ecpay_merchant_id,
      ecpay_hash_key_encrypted: encrypt(ecpay_hash_key),
      ecpay_hash_iv_encrypted: encrypt(ecpay_hash_iv),
      success_url, failure_url, webhook_url, is_staging
    }).select().single();

    if (error) throw error;
    
    res.status(201).json({ 
      merchant: { id: data.id, code: data.code, name: data.name },
      api_key: apiKey,  // 只顯示一次！
      message: '請妥善保存 API Key，此為唯一顯示機會'
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 查詢商家
app.get('/api/v1/merchants', authAdmin, async (_, res: Response) => {
  const { data } = await supabase.from('gateway_merchants').select('id, code, name, ecpay_merchant_id, is_staging, is_active, created_at');
  res.json({ merchants: data });
});

// ============================================
// 金流 API
// ============================================

// 建立結帳
app.post('/api/v1/payment/checkout', authMerchant, async (req: Request, res: Response) => {
  try {
    const merchant = (req as any).merchant;
    const { amount, item_name, order_id, customer_email, customer_name, customer_phone, return_url, metadata } = req.body;

    if (!amount || !item_name) {
      return res.status(400).json({ error: 'amount and item_name required' });
    }

    const tradeNo = generateTradeNo('PAY');
    
    // 建立交易紀錄
    const { data: tx, error } = await supabase.from('gateway_transactions').insert({
      merchant_id: merchant.id,
      merchant_trade_no: tradeNo,
      amount: Math.round(amount),
      item_name, order_id, customer_email, customer_name, customer_phone,
      return_url: return_url || merchant.success_url,
      metadata: metadata || {},
      expires_at: new Date(Date.now() + 30 * 60 * 1000).toISOString()  // 30分鐘
    }).select().single();

    if (error) throw error;

    const baseUrl = `${req.protocol}://${req.get('host')}`;
    
    res.status(201).json({
      transaction_id: tx.id,
      trade_no: tradeNo,
      checkout_url: `${baseUrl}/api/v1/payment/checkout/${tradeNo}`,
      expires_at: tx.expires_at
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 付款頁（自動提交到 ECPay）
app.get('/api/v1/payment/checkout/:tradeNo', async (req: Request, res: Response) => {
  try {
    const { tradeNo } = req.params;
    
    // 取得交易
    const { data: tx } = await supabase.from('gateway_transactions')
      .select('*, merchant:gateway_merchants(*)')
      .eq('merchant_trade_no', tradeNo)
      .single();

    if (!tx) return res.status(404).send('交易不存在');
    if (tx.status !== 'pending') return res.status(400).send('交易已處理');
    if (new Date(tx.expires_at) < new Date()) return res.status(400).send('交易已過期');

    const merchant = tx.merchant;
    const hashKey = decrypt(merchant.ecpay_hash_key_encrypted);
    const hashIV = decrypt(merchant.ecpay_hash_iv_encrypted);

    const baseUrl = `${req.protocol}://${req.get('host')}`;
    
    // ECPay 參數
    const params: Record<string, string> = {
      MerchantID: merchant.ecpay_merchant_id,
      MerchantTradeNo: tx.merchant_trade_no,
      MerchantTradeDate: new Date().toLocaleString('zh-TW', { timeZone: 'Asia/Taipei' }).replace(/\//g, '/'),
      PaymentType: 'aio',
      TotalAmount: String(tx.amount),
      TradeDesc: encodeURIComponent('線上購物'),
      ItemName: tx.item_name,
      ReturnURL: `${baseUrl}/api/v1/payment/webhook`,
      OrderResultURL: tx.return_url || merchant.success_url,
      ChoosePayment: 'ALL',
      EncryptType: '1',
      NeedExtraPaidInfo: 'Y'
    };

    if (tx.customer_email) params.Email = tx.customer_email;

    params.CheckMacValue = calculateCheckMac(params, hashKey, hashIV);

    // 產生自動提交表單
    const ecpayUrl = merchant.is_staging ? ECPAY.payment.staging : ECPAY.payment.production;
    const inputs = Object.entries(params).map(([k, v]) => `<input type="hidden" name="${k}" value="${v}">`).join('');
    
    res.send(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>付款中...</title></head>
<body><p>正在跳轉到付款頁面...</p><form id="f" method="POST" action="${ecpayUrl}">${inputs}</form>
<script>document.getElementById('f').submit();</script></body></html>`);
  } catch (err: any) {
    res.status(500).send('系統錯誤');
  }
});

// 金流 Webhook（ECPay 回調）
app.post('/api/v1/payment/webhook', async (req: Request, res: Response) => {
  try {
    const params = req.body as Record<string, string>;
    const tradeNo = params.MerchantTradeNo;

    // 記錄 Webhook
    const logData = {
      type: 'payment',
      source_ip: req.ip,
      raw_body: JSON.stringify(params),
      check_mac_valid: false
    };

    // 取得交易和商家
    const { data: tx } = await supabase.from('gateway_transactions')
      .select('*, merchant:gateway_merchants(*)')
      .eq('merchant_trade_no', tradeNo)
      .single();

    if (!tx) {
      await supabase.from('gateway_webhook_logs').insert({ ...logData, error_message: 'Transaction not found' });
      return res.send('0|Transaction not found');
    }

    const merchant = tx.merchant;
    const hashKey = decrypt(merchant.ecpay_hash_key_encrypted);
    const hashIV = decrypt(merchant.ecpay_hash_iv_encrypted);

    // 驗證 CheckMacValue
    const isValid = verifyCheckMac(params, hashKey, hashIV);
    logData.check_mac_valid = isValid;
    logData.merchant_id = merchant.id;
    logData.transaction_id = tx.id;

    if (!isValid) {
      await supabase.from('gateway_webhook_logs').insert({ ...logData, error_message: 'Invalid CheckMacValue' });
      return res.send('0|CheckMacValue Error');
    }

    // 更新交易狀態
    const rtnCode = params.RtnCode;
    const isSuccess = rtnCode === '1';
    
    const updateData: Record<string, any> = {
      ecpay_trade_no: params.TradeNo,
      payment_type: params.PaymentType,
      ecpay_response: params,
      status: isSuccess ? 'authorized' : 'failed',
      ...(isSuccess ? { authorized_at: new Date().toISOString() } : { failed_at: new Date().toISOString(), error_code: rtnCode, error_message: params.RtnMsg })
    };

    if (params.card4no) updateData.card_last4 = params.card4no;
    if (params.gwsr) updateData.auth_code = params.gwsr;

    await supabase.from('gateway_transactions').update(updateData).eq('id', tx.id);

    // 記錄 Webhook
    await supabase.from('gateway_webhook_logs').insert({ 
      ...logData, 
      processed: true, 
      process_result: isSuccess ? 'success' : 'failed',
      processed_at: new Date().toISOString()
    });

    // 通知商家
    if (merchant.webhook_url) {
      try {
        await fetch(merchant.webhook_url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            event: 'payment.' + (isSuccess ? 'success' : 'failed'),
            transaction_id: tx.id,
            trade_no: tradeNo,
            order_id: tx.order_id,
            amount: tx.amount,
            status: updateData.status
          })
        });
      } catch (e) { /* 忽略通知失敗 */ }
    }

    res.send('1|OK');
  } catch (err: any) {
    console.error('Webhook error:', err);
    res.send('0|Error');
  }
});

// 查詢交易
app.get('/api/v1/payment/transaction/:id', authMerchant, async (req: Request, res: Response) => {
  const merchant = (req as any).merchant;
  const { data: tx } = await supabase.from('gateway_transactions')
    .select('id, merchant_trade_no, ecpay_trade_no, amount, status, payment_type, item_name, order_id, created_at, authorized_at')
    .eq('id', req.params.id)
    .eq('merchant_id', merchant.id)
    .single();
  
  if (!tx) return res.status(404).json({ error: 'Not found' });
  res.json({ transaction: tx });
});

// 交易列表
app.get('/api/v1/payment/transactions', authMerchant, async (req: Request, res: Response) => {
  const merchant = (req as any).merchant;
  const { status, limit = '20', offset = '0' } = req.query;
  
  let query = supabase.from('gateway_transactions')
    .select('id, merchant_trade_no, amount, status, item_name, order_id, created_at')
    .eq('merchant_id', merchant.id)
    .order('created_at', { ascending: false })
    .range(Number(offset), Number(offset) + Number(limit) - 1);

  if (status) query = query.eq('status', status);

  const { data } = await query;
  res.json({ transactions: data });
});

// ============================================
// 物流 API
// ============================================

// 建立物流單
app.post('/api/v1/logistics/shipment', authMerchant, async (req: Request, res: Response) => {
  try {
    const merchant = (req as any).merchant;
    const { 
      logistics_type, logistics_sub_type,
      receiver_name, receiver_phone, receiver_email,
      receiver_address, receiver_store_id, receiver_store_name,
      sender_name, sender_phone, sender_address,
      goods_name, goods_amount = 1,
      shipping_fee = 0, cod_amount = 0,
      order_id, transaction_id, metadata
    } = req.body;

    if (!logistics_type || !logistics_sub_type || !receiver_name || !receiver_phone) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // 超商取貨需要 store_id
    if (logistics_type === 'cvs' && !receiver_store_id) {
      return res.status(400).json({ error: 'receiver_store_id required for CVS' });
    }

    // 宅配需要地址
    if (logistics_type === 'home' && !receiver_address) {
      return res.status(400).json({ error: 'receiver_address required for home delivery' });
    }

    const tradeNo = generateTradeNo('SHP');

    const { data: shipment, error } = await supabase.from('gateway_shipments').insert({
      merchant_id: merchant.id,
      transaction_id,
      merchant_trade_no: tradeNo,
      logistics_type,
      logistics_sub_type,
      receiver_name, receiver_phone, receiver_email,
      receiver_address, receiver_store_id, receiver_store_name,
      sender_name: sender_name || merchant.name,
      sender_phone, sender_address,
      goods_name: goods_name || '商品一批',
      goods_amount,
      shipping_fee, cod_amount,
      order_id,
      metadata: metadata || {}
    }).select().single();

    if (error) throw error;

    res.status(201).json({
      shipment_id: shipment.id,
      trade_no: tradeNo,
      status: 'pending',
      message: '物流單已建立，請呼叫 /create-ecpay 產生綠界物流單'
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 產生綠界物流單
app.post('/api/v1/logistics/shipment/:id/create-ecpay', authMerchant, async (req: Request, res: Response) => {
  try {
    const merchant = (req as any).merchant;
    
    const { data: shipment } = await supabase.from('gateway_shipments')
      .select('*')
      .eq('id', req.params.id)
      .eq('merchant_id', merchant.id)
      .single();

    if (!shipment) return res.status(404).json({ error: 'Shipment not found' });
    if (shipment.status !== 'pending') return res.status(400).json({ error: 'Shipment already processed' });

    const hashKey = decrypt(merchant.ecpay_hash_key_encrypted);
    const hashIV = decrypt(merchant.ecpay_hash_iv_encrypted);
    const baseUrl = `${req.protocol}://${req.get('host')}`;

    // 基本參數
    const params: Record<string, string> = {
      MerchantID: merchant.ecpay_merchant_id,
      MerchantTradeNo: shipment.merchant_trade_no,
      MerchantTradeDate: new Date().toLocaleString('zh-TW', { timeZone: 'Asia/Taipei' }).replace(/\//g, '/'),
      LogisticsType: shipment.logistics_type === 'cvs' ? 'CVS' : 'Home',
      LogisticsSubType: shipment.logistics_sub_type,
      GoodsName: shipment.goods_name,
      GoodsAmount: String(shipment.goods_amount),
      SenderName: shipment.sender_name,
      SenderPhone: shipment.sender_phone || '',
      ReceiverName: shipment.receiver_name,
      ReceiverCellPhone: shipment.receiver_phone,
      ServerReplyURL: `${baseUrl}/api/v1/logistics/webhook`
    };

    // 超商取貨
    if (shipment.logistics_type === 'cvs') {
      params.ReceiverStoreID = shipment.receiver_store_id;
      if (shipment.cod_amount > 0) {
        params.IsCollection = 'Y';
        params.CollectionAmount = String(shipment.cod_amount);
      } else {
        params.IsCollection = 'N';
      }
    } else {
      // 宅配
      params.SenderAddress = shipment.sender_address || '';
      params.SenderZipCode = shipment.sender_zipcode || '';
      params.ReceiverAddress = shipment.receiver_address;
      params.ReceiverZipCode = shipment.receiver_zipcode || '';
      params.Temperature = '0001';  // 常溫
      params.Distance = '00';       // 同縣市
      params.Specification = '0001'; // 60cm
    }

    params.CheckMacValue = calculateCheckMac(params, hashKey, hashIV);

    // 呼叫綠界 API
    const ecpayUrl = merchant.is_staging ? ECPAY.logistics.create.staging : ECPAY.logistics.create.production;
    
    const formData = new URLSearchParams(params);
    const response = await fetch(ecpayUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: formData
    });

    const resultText = await response.text();
    const result = Object.fromEntries(new URLSearchParams(resultText));

    // 更新物流單
    const isSuccess = result.RtnCode === '1' || result.RtnCode === '300';
    
    await supabase.from('gateway_shipments').update({
      status: isSuccess ? 'created' : 'failed',
      logistics_id: result.AllPayLogisticsID || null,
      all_pay_logistics_id: result.AllPayLogisticsID || null,
      cvs_payment_no: result.CVSPaymentNo || null,
      cvs_validation_no: result.CVSValidationNo || null,
      ecpay_response: result,
      status_message: result.RtnMsg
    }).eq('id', shipment.id);

    if (!isSuccess) {
      return res.status(400).json({ error: result.RtnMsg, ecpay_response: result });
    }

    res.json({
      shipment_id: shipment.id,
      logistics_id: result.AllPayLogisticsID,
      cvs_payment_no: result.CVSPaymentNo,
      cvs_validation_no: result.CVSValidationNo,
      status: 'created'
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// 物流 Webhook
app.post('/api/v1/logistics/webhook', async (req: Request, res: Response) => {
  try {
    const params = req.body as Record<string, string>;
    const tradeNo = params.MerchantTradeNo;

    const { data: shipment } = await supabase.from('gateway_shipments')
      .select('*, merchant:gateway_merchants(*)')
      .eq('merchant_trade_no', tradeNo)
      .single();

    if (!shipment) return res.send('0|Not found');

    const merchant = shipment.merchant;
    const hashKey = decrypt(merchant.ecpay_hash_key_encrypted);
    const hashIV = decrypt(merchant.ecpay_hash_iv_encrypted);

    const isValid = verifyCheckMac(params, hashKey, hashIV);
    
    // 記錄
    await supabase.from('gateway_webhook_logs').insert({
      type: 'logistics',
      merchant_id: merchant.id,
      shipment_id: shipment.id,
      source_ip: req.ip,
      raw_body: JSON.stringify(params),
      check_mac_valid: isValid,
      processed: true,
      processed_at: new Date().toISOString()
    });

    if (!isValid) return res.send('0|CheckMacValue Error');

    // 狀態對應
    const statusCode = params.RtnCode;
    let newStatus = shipment.status;
    const now = new Date().toISOString();

    // 超商狀態碼
    if (['2030', '2063', '2073', '2083'].includes(statusCode)) newStatus = 'arrived';
    else if (['2067', '2074', '2084', '3024'].includes(statusCode)) newStatus = 'picked_up';
    else if (['2031'].includes(statusCode)) newStatus = 'shipping';
    else if (['2032', '2033'].includes(statusCode)) newStatus = 'returned';

    // 宅配狀態碼
    if (['3003', '3006'].includes(statusCode)) newStatus = 'shipping';
    else if (['3001'].includes(statusCode)) newStatus = 'arrived';

    const updateData: Record<string, any> = {
      status: newStatus,
      status_message: params.RtnMsg,
      tracking_number: params.BookingNote || shipment.tracking_number
    };

    if (newStatus === 'shipped') updateData.shipped_at = now;
    if (newStatus === 'arrived') updateData.arrived_at = now;
    if (newStatus === 'picked_up') updateData.picked_up_at = now;

    await supabase.from('gateway_shipments').update(updateData).eq('id', shipment.id);

    // 通知商家
    if (merchant.webhook_url) {
      try {
        await fetch(merchant.webhook_url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            event: 'logistics.status_changed',
            shipment_id: shipment.id,
            trade_no: tradeNo,
            order_id: shipment.order_id,
            status: newStatus,
            status_message: params.RtnMsg
          })
        });
      } catch (e) { /* 忽略 */ }
    }

    res.send('1|OK');
  } catch (err: any) {
    res.send('0|Error');
  }
});

// 超商地圖
app.get('/api/v1/logistics/cvs-map', authMerchant, async (req: Request, res: Response) => {
  const merchant = (req as any).merchant;
  const { sub_type = 'FAMIC2C', callback_url } = req.query;
  
  if (!callback_url) return res.status(400).json({ error: 'callback_url required' });

  const hashKey = decrypt(merchant.ecpay_hash_key_encrypted);
  const hashIV = decrypt(merchant.ecpay_hash_iv_encrypted);

  const params: Record<string, string> = {
    MerchantID: merchant.ecpay_merchant_id,
    MerchantTradeNo: generateTradeNo('MAP'),
    LogisticsType: 'CVS',
    LogisticsSubType: sub_type as string,
    IsCollection: 'N',
    ServerReplyURL: callback_url as string
  };

  params.CheckMacValue = calculateCheckMac(params, hashKey, hashIV);

  const mapUrl = merchant.is_staging ? ECPAY.logistics.map.staging : ECPAY.logistics.map.production;
  const inputs = Object.entries(params).map(([k, v]) => `<input type="hidden" name="${k}" value="${v}">`).join('');

  res.send(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>選擇門市</title></head>
<body><form id="f" method="POST" action="${mapUrl}">${inputs}</form>
<script>document.getElementById('f').submit();</script></body></html>`);
});

// 查詢物流單
app.get('/api/v1/logistics/shipment/:id', authMerchant, async (req: Request, res: Response) => {
  const merchant = (req as any).merchant;
  const { data } = await supabase.from('gateway_shipments')
    .select('id, merchant_trade_no, logistics_id, logistics_type, logistics_sub_type, status, status_message, tracking_number, receiver_name, receiver_store_name, order_id, created_at')
    .eq('id', req.params.id)
    .eq('merchant_id', merchant.id)
    .single();
  
  if (!data) return res.status(404).json({ error: 'Not found' });
  res.json({ shipment: data });
});

// ============================================
// 啟動
// ============================================
app.listen(Number(PORT), () => {
  console.log(`🚀 ECPay Gateway running on port ${PORT}`);
  console.log(`📚 Endpoints:`);
  console.log(`   POST /api/v1/merchants (Admin)`);
  console.log(`   POST /api/v1/payment/checkout`);
  console.log(`   GET  /api/v1/payment/checkout/:tradeNo`);
  console.log(`   POST /api/v1/payment/webhook`);
  console.log(`   POST /api/v1/logistics/shipment`);
  console.log(`   POST /api/v1/logistics/shipment/:id/create-ecpay`);
  console.log(`   GET  /api/v1/logistics/cvs-map`);
});

export default app;
