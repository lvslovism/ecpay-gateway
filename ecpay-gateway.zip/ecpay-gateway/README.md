# ECPay Gateway

金流 + 物流統一閘道，搭配 Supabase 使用。

## 快速開始

```bash
# 1. 安裝依賴
npm install

# 2. 設定環境變數
cp .env.example .env
# 編輯 .env 填入：
# - SUPABASE_URL
# - SUPABASE_SERVICE_KEY
# - ENCRYPTION_KEY (64字元 hex，用 node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
# - ADMIN_API_KEY (自訂管理員金鑰)

# 3. 啟動
npm run dev
```

## API 端點

### 商家管理（Admin）

```bash
# 建立商家（回傳 API Key，只顯示一次！）
curl -X POST http://localhost:3000/api/v1/merchants \
  -H "x-api-key: YOUR_ADMIN_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "code": "minjie",
    "name": "敏捷商店",
    "ecpay_merchant_id": "3002607",
    "ecpay_hash_key": "pwFHCqoQZGmho4w6",
    "ecpay_hash_iv": "EkRm7iFT261dpevs",
    "success_url": "https://shop.example.com/success",
    "failure_url": "https://shop.example.com/failure",
    "webhook_url": "https://n8n.example.com/webhook/ecpay",
    "is_staging": true
  }'
```

### 金流

```bash
# 建立結帳
curl -X POST http://localhost:3000/api/v1/payment/checkout \
  -H "x-api-key: gk_xxx" \
  -H "Content-Type: application/json" \
  -d '{
    "amount": 1000,
    "item_name": "商品一批",
    "order_id": "order_123",
    "customer_email": "test@example.com"
  }'

# 回應
{
  "transaction_id": "uuid",
  "trade_no": "PAYM5ABC1234",
  "checkout_url": "http://localhost:3000/api/v1/payment/checkout/PAYM5ABC1234"
}

# 導向用戶到 checkout_url，自動跳轉到綠界付款
```

### 物流

```bash
# 1. 建立物流單
curl -X POST http://localhost:3000/api/v1/logistics/shipment \
  -H "x-api-key: gk_xxx" \
  -H "Content-Type: application/json" \
  -d '{
    "logistics_type": "cvs",
    "logistics_sub_type": "FAMIC2C",
    "receiver_name": "王小明",
    "receiver_phone": "0912345678",
    "receiver_store_id": "006598",
    "receiver_store_name": "全家中山店",
    "goods_name": "保健食品",
    "order_id": "order_123"
  }'

# 2. 產生綠界物流單
curl -X POST http://localhost:3000/api/v1/logistics/shipment/{id}/create-ecpay \
  -H "x-api-key: gk_xxx"

# 3. 超商地圖選店
# 在瀏覽器開啟：
http://localhost:3000/api/v1/logistics/cvs-map?sub_type=FAMIC2C&callback_url=https://your-callback
```

## 部署到 Railway

1. 推送到 GitHub
2. Railway 連接 Repo
3. 設定環境變數
4. 部署完成

## Webhook 流程

```
用戶付款完成
    ↓
ECPay POST → /api/v1/payment/webhook
    ↓
Gateway 驗證 CheckMacValue
    ↓
更新 gateway_transactions 狀態
    ↓
POST 通知商家 webhook_url
    ↓
n8n 接收 → 更新 Medusa 訂單
```

## 安全機制

- ECPay 憑證 AES-256 加密儲存
- API Key 認證
- CheckMacValue 驗證所有 Webhook
- Webhook 完整紀錄（稽核用）
